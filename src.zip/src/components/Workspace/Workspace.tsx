import './Workspace.css';

import { useMemo } from 'react';

import { Explorer } from '../../core/Explorer';


import AxisTop from './AxisTop/AxisTop';
import AxisLeft from './AxisLeft/AxisLeft';
import GridCanvas from "./GridCanvas/GridCanvas";
import OverlayCanvas from "./OverlayCanvas/OverlayCanvas";

import NumberPanel from './NumberPanel/NumberPanel';
import { nearestBoundary } from '../../math/functions/FunctionEngine';



function Workspace() {

    const explorer = useMemo(() => {

    const ex = new Explorer();

    ex.functionEngine.setFunction(
        x => nearestBoundary(x)
    );

    ex.numberSystem.setBase(10);

    ex.primeCache.loadFromText(`
        2 3 5 7 11 13 17 19 23 29
        31 37 41 43 47 53 59 61
    `);

    return ex;

}, []);
    const handleSeePath = (): void => {

        const cell = explorer.selection.getSelectedCell(
            explorer.table
        );
    
        if (!cell) {
            return;
        }
    
        explorer.buildPath(cell);
    
    };

    const handleSeeModCurve = (): void => {

        const cell =
            explorer.selection.getSelectedCell(
                explorer.table
            );
    
        if (!cell) {
            return;
        }
    
        explorer.buildModularCurve(cell);
    
    };
    
    return (
    <div className="workspace">
        <div className="overWorkspace">
        <NumberPanel explorer={explorer} />
            <div className="numberActionArea">
                <div className="seePathBt NumberpanelBt" onClick={handleSeePath}>See path</div>
                <div className="seeModularCurveBt NumberpanelBt" onClick={handleSeeModCurve}>See mod curve</div>
                </div>
        </div>
        <div className="innerWorkspace" >
            <div className="corner" />

            <AxisTop explorer={explorer} />

            <AxisLeft explorer={explorer} />

            <div className="canvas-container">

<GridCanvas explorer={explorer} />

<OverlayCanvas explorer={explorer} />

</div>
        </div> 
        </div> 
    );

}

export default Workspace;